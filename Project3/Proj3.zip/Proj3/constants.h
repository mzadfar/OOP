#ifndef _CONSTANTS_H_
#define _CONSTANTS_H_

int const MIN_ALLOWED_COLOR_VAL = 0;
int const MAX_ALLOWED_COLOR_VAL = 1000;
int const ROW_INITIAL_VAL = -99999;
int const COL_INITIAL_VAL = -99999;
string const PPM_MAGIC_STRING = "P3";

#endif
