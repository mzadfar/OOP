#include <iostream>
#include <fstream>

using namespace std;

#include "ColorImageClass.h"

//Programmer: Amin Hasanzadeh
//Date: November 2 2019
//Purpose: develop a program to modifying pictureson acomputer

void inMenuChoice(int &mainMenuChoic);

void rectSpecMtd(int &upLeftRecRow, int &upLeftRecClmn, int &lwrRightRecRow, int &lwrRightRecClmn);

void colorChoice(int &colorOptnNum);

bool validIntInput(int &inValConsl, int minInVal, int &mxInVal);

#ifdef ANDREW_TEST
#include "andrewTest.h"
#else
int main()
{
  string fileNamePpm, fileNameContPtrn, fileNamePpmInsrt, fileNamePpmOut;
  int mainMenuChoic, upLeftRecRow, upLeftRecClmn, lwrRightRecRow, lwrRightRecClmn, recColor = 0, recFillOptn = 0, pattColor = 0, transpColor = 0, colorOptnNum, mxValColor;

  cout << "Enter string for PPM image file name to load: ";
  cin >> fileNamePpm;

  ColorImageClass ppmImage;
  ppmImage.getChkPpmFile(mxValColor, fileNamePpm);
  RowColumnClass rowColImage;
  ColorClass colorImage;  
  colorImage.setMaxColor(mxValColor);

  do
  {
    inMenuChoice(mainMenuChoic);

    if (mainMenuChoic == 1)
    {
      rectSpecMtd(upLeftRecRow, upLeftRecClmn, lwrRightRecRow, lwrRightRecClmn);
      
      colorChoice(colorOptnNum);

      cout << "Enter int for rectangle color: ";
      validIntInput(recColor, 1, colorOptnNum);

      if (recColor == 1)
      {
        colorImage.setToRed();
      }
      if (recColor == 2)
      {
        colorImage.setToGreen();
      }
      if (recColor == 3)
      {
        colorImage.setToBlue();
      }
      if (recColor == 4)
      {
        colorImage.setToBlack();
      }
      if (recColor == 5)
      {
        colorImage.setToWhite();
      }

      cout << "1. No" << endl;
      cout << "2. Yes" << endl;

      cout << "Enter int for rectangle fill option: ";
      cin >> recFillOptn;
      cout << mxValColor << "Amin" << endl;


      if (recFillOptn == 1)
      {
        for (int i = upLeftRecRow; i < lwrRightRecRow + 1; i++)
        {
          if ((i == upLeftRecRow) || ((i == lwrRightRecRow)))
          {
            for (int j = upLeftRecClmn; j < lwrRightRecClmn + 1; j++)  
            {
              rowColImage.setRowCol(i,j);
              ppmImage.setColorAtLocation(rowColImage,colorImage);
            }
          }
          else
          {
            rowColImage.setRowCol(i,upLeftRecClmn);
            ppmImage.setColorAtLocation(rowColImage,colorImage);
            rowColImage.setRowCol(i,lwrRightRecClmn);
            ppmImage.setColorAtLocation(rowColImage,colorImage);
          }
        }
      }

      if (recFillOptn == 2)
      {
        for (int i = upLeftRecRow; i < lwrRightRecRow + 1; i++)
        {
          for (int j = upLeftRecClmn; j < lwrRightRecClmn + 1; j++)  
          {
            rowColImage.setRowCol(i,j);
            ppmImage.setColorAtLocation(rowColImage,colorImage);
          }
        }
      }

    }
    else if (mainMenuChoic == 2)
    {
      cout << "Enter string for file name containing pattern: ";  
      cin >>  fileNameContPtrn;

      cout << "Enter upper left corner of pattern row and column: ";
      cin >> upLeftRecRow;
      cin >> upLeftRecClmn; 

      colorChoice(colorOptnNum);

      cout << "Enter int for pattern color: ";
      validIntInput(pattColor, 1, colorOptnNum);
      if (pattColor == 1)
      {
        colorImage.setToRed();
      }
      if (pattColor == 2)
      {
        colorImage.setToGreen();
      }
      if (pattColor == 3)
      {
        colorImage.setToBlue();
      }
      if (pattColor == 4)
      {
        colorImage.setToBlack();
      }
      if (pattColor == 5)
      {
        colorImage.setToWhite();
      }

      ppmImage.getChkTxtFile(upLeftRecRow, upLeftRecClmn, colorImage, fileNameContPtrn);
      
    }
    else if (mainMenuChoic == 3)
    {
      cout << "Enter string for file name of PPM image to insert: ";  
      cin >>  fileNamePpmInsrt;

      cout << "Enter upper left corner to insert image row and column: ";
      cin >> upLeftRecRow;
      cin >> upLeftRecClmn;

      colorChoice(colorOptnNum);

      cout << "Enter int for transparecy color: ";
      validIntInput(transpColor, 1, colorOptnNum);
      if (transpColor == 1)
      {
        colorImage.setToRed();
      }
      if (transpColor == 2)
      {
        colorImage.setToGreen();
      }
      if (transpColor == 3)
      {
        colorImage.setToBlue();
      }
      if (transpColor == 4)
      {
        colorImage.setToBlack();
      }
      if (transpColor == 5)
      {
        colorImage.setToWhite();
      }

      ppmImage.getChkPpmInsrt(upLeftRecRow, upLeftRecClmn, colorImage, fileNamePpmInsrt);

    }
    else if (mainMenuChoic == 4)
    {
      cout << "Enter string for PPM file name to output: ";
      cin >>  fileNamePpmOut;

      ppmImage.writeOutPpmFile(mxValColor, fileNamePpmOut);
    }
  }
  while (mainMenuChoic != 5);

  cout << "Thank you for using this program" << endl;

  return 0;
}
#endif

void inMenuChoice(int &mainMenuChoic)
{
  int i = 0;

  cout << ++i << ". Annotate image with rectangle" << endl;
  cout << ++i << ". Annotate image with pattern from file" << endl;
  cout << ++i << ". Insert another imag" << endl;
  cout << ++i << ". Write out current image" << endl;
  cout << ++i << ". Exit the program" << endl;

  cout << "Enter int for main menu choice: ";
  validIntInput(mainMenuChoic, 1, i);
}

void rectSpecMtd(int &upLeftRecRow, int &upLeftRecClmn, int &lwrRightRecRow, int &lwrRightRecClmn)
{
  int rectSpecMtd, ctrRowRec, ctrClmnRec, numRowRec, numClmnRec, hlfNumRowRec, hlfNumClmnRec, i = 0;

  cout << ++i << ". Specify upper left and lower right corners of rectangle" << endl;
  cout << ++i << ". Specify upper left corner and dimensions of rectangle" << endl;
  cout << ++i << ". Specify extent from center of rectangle" << endl;

  cout << "Enter int for rectangle specification method: "; 
  validIntInput(rectSpecMtd, 1, i);

  if (rectSpecMtd == 1)
  {
    cout << "Enter upper left corner row and column: ";
    cin >> upLeftRecRow;
    cin >> upLeftRecClmn; 
    cout << "Enter lower right corner row and column: ";
    cin >> lwrRightRecRow;
    cin >> lwrRightRecClmn; 
  }
  else if (rectSpecMtd == 2) 
  {
    cout << "Enter upper left corner row and column: ";
    cin >> upLeftRecRow;
    cin >> upLeftRecClmn; 
    cout << "Enter int for number of rows: ";
    cin >> numRowRec;
    cout << "Enter int for number of columns: ";
    cin >> numClmnRec;
    lwrRightRecRow = numRowRec + upLeftRecRow;
    lwrRightRecClmn = numClmnRec + upLeftRecClmn;
  }
  else if (rectSpecMtd == 3) 
  {
    cout << "Enter rectangle center row and column: ";
    cin >> ctrRowRec;
    cin >> ctrClmnRec;
    cout << "Enter int for half number of rows: ";
    cin >> hlfNumRowRec;
    cout << "Enter int for half number of columns: ";
    cin >> hlfNumClmnRec;

    upLeftRecRow = ctrRowRec - hlfNumRowRec;
    upLeftRecClmn = ctrClmnRec - hlfNumClmnRec;
    lwrRightRecRow = ctrRowRec + hlfNumRowRec;
    lwrRightRecClmn = ctrClmnRec + hlfNumClmnRec;
  }
}

void colorChoice(int &colorOptnNum)
{
  colorOptnNum = 1;

  cout << colorOptnNum++ << ". Red" << endl;
  cout << colorOptnNum++ << ". Green" << endl;
  cout << colorOptnNum++ << ". Blue" << endl;
  cout << colorOptnNum++ << ". Black" << endl;
  cout << colorOptnNum++ << ". White" << endl;
}

bool validIntInput(int &inValConsl, int minInVal, int &mxInVal)
{
  bool validInputFound;

  validInputFound = false;
  while (!validInputFound)
  {
    cin >> inValConsl;
    if (cin.fail())
    {
      cin.clear();
      cin.ignore(200, '\n');
      cout << "Fail state!" << endl;
      cout << "Try again - Enter a number between " << minInVal << " and " << minInVal << " : ";
    }
    else
    {
      if ((inValConsl >= minInVal) && (inValConsl <= mxInVal))
      {
        validInputFound = true;
      }
      else
      {
        cout << "Try again - Enter a number between " << minInVal << " and " << mxInVal << " : ";    
      }    
    }
  }

  return !validInputFound;
}
