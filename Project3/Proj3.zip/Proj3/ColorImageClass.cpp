#include <iostream>
#include <fstream>

using namespace std;

#include "constants.h"
#include "ColorImageClass.h"

//Implementing functions of ColorImageClass:
//Default constructor that sets all pixels in the image to black
ColorImageClass::ColorImageClass()
{
  rowSize = 0;
  colSize = 0;
  arr = NULL;
}

//A public fuction to assign input color to all pixels in the image
void ColorImageClass::initializeTo(ColorClass &inColor)
{
  for (int i = 0; i < rowSize; i++)
    for (int j = 0; j < colSize; j++)  
      arr[i][j].setTo(inColor); 
}

//A public fuction to add corresponding pixels of the right hand side 
//to the current image and replace the resulted image in the 
//location of current image
bool ColorImageClass::addImageTo(ColorImageClass &rhsImg)
{
  bool retVal = false;

  for (int i = 0; i < rowSize; i++)
    for (int j = 0; j < colSize; j++)  
      if (arr[i][j].addColor(rhsImg.arr[i][j]))
        retVal = true;
           
  return retVal;
}

//A public fuction to add corresponding pixels of the specific number
//of input images and replace the resulted image in the location
//of current image
bool ColorImageClass::addImages(int numImgsToAdd, 
                                ColorImageClass imagesToAdd [])
{
  bool retVal = false;
  
  //Replace image number zero with current index image 
  for (int i = 0; i < rowSize; i++)
    for (int j = 0; j < colSize; j++)
      arr[i][j].setTo(imagesToAdd[0].arr[i][j]);

  for (int i = 1; i < numImgsToAdd; i++) 
    if (addImageTo(imagesToAdd[i]))
      retVal = true;
         
  return retVal;
}

//A public fuction to set the color of an specific pixel location 
bool ColorImageClass::setColorAtLocation(RowColumnClass &inRowCol,
                                         ColorClass &inColor)
{
  bool retVal = true;

  int i = inRowCol.getRow();
  int j = inRowCol.getCol();

  if ((i >= 0) && (i < rowSize) && (j >= 0) && (j < colSize))
    arr[i][j].setTo(inColor);
  else 
    retVal = false; 

  return retVal;
}

//A public fuction to return the color of an specific pixel location  
bool ColorImageClass::getColorAtLocation(RowColumnClass &inRowCol,
                                         ColorClass &outColor)
{
  bool retVal = true;

  int i = inRowCol.getRow();
  int j = inRowCol.getCol();

  if ((i >= 0) && (i < rowSize) && (j >= 0) && (j < colSize))
    outColor.setTo(arr[i][j]);
  else 
    retVal = false; 

  return retVal;
}

bool ColorImageClass::getChkPpmFile(int &mxValColor, string fileNamePpm)
{
  string ppmMagicNum;

  ifstream inFile;
  bool validInputFound = true;

  inFile.open(fileNamePpm.c_str());

  if (inFile.fail())
  {
    cout << "Unable to open input file!" << endl;
  }

  inFile >> ppmMagicNum;
  if (ppmMagicNum != PPM_MAGIC_STRING)
  {
    cout << "The entered PPM file is not valid!" << endl;
    validInputFound = false;
  }
  if (inFile.eof())
  {
    cout << "EOF before reading PPM magic number" << endl;
    validInputFound = false;
  }
  else if (inFile.fail())
  {
    inFile.clear();
    inFile.ignore(200, '\n');
    validInputFound = false;
  }

  inFile >> colSize;
  if (inFile.eof())
  {
    cout << "EOF before reading row-size" << endl;
    validInputFound = false;
  }
  else if (inFile.fail())
  {
    inFile.clear();
    inFile.ignore(200, '\n');
    validInputFound = false;
  }

  inFile >> rowSize;
  if (inFile.eof())
  {
    cout << "EOF before reading column-Size" << endl;
    validInputFound = false;
  }
  else if (inFile.fail())
  {
    inFile.clear();
    inFile.ignore(200, '\n');
    validInputFound = false;
  }

  inFile >> mxValColor;
  if (inFile.eof())
  {
    cout << "EOF before reading Max color value" << endl;
    validInputFound = false;
  }
  else if (inFile.fail())
  {
    inFile.clear();
    inFile.ignore(200, '\n');
    validInputFound = false;
  }

  arr = new ColorClass*[rowSize];

  for (int i = 0; i < rowSize; i++)
  {
    arr[i] = new ColorClass[colSize];
  }

  for (int i = 0; i < rowSize; i++)
  {
    for (int j = 0; j < colSize; j++)
    {
      arr[i][j].readFrmFile(inFile);
    }
  }

  inFile.close();

  return validInputFound;
}

bool ColorImageClass::getChkTxtFile(int &upLeftRecRow, int &upLeftRecClmn, ColorClass &inColor, string fileNameContPtrn)
{
  int rowSizePtrn, colSizePtrn, tempInFile;
  ifstream inFile;
  bool validInputFound = true;

  inFile.open(fileNameContPtrn.c_str());

  if (inFile.fail())
  {
    cout << "Unable to open input file!" << endl;
  }

  inFile >> colSizePtrn;
  if (inFile.eof())
  {
    cout << "EOF before reading column-size" << endl;
    validInputFound = false;
  }
  else if (inFile.fail())
  {
    inFile.clear();
    inFile.ignore(200, '\n');
    validInputFound = false;
  }

  inFile >> rowSizePtrn;
  if (inFile.eof())
  {
    cout << "EOF before reading row-Size" << endl;
    validInputFound = false;
  }
  else if (inFile.fail())
  {
    inFile.clear();
    inFile.ignore(200, '\n');
    validInputFound = false;
  }

  for (int i = 0; i < rowSizePtrn; i++)
  {
    for (int j = 0; j < colSizePtrn; j++)  
    {
      inFile >> tempInFile;
      if (tempInFile == 1)
      {
        arr[upLeftRecRow+i][upLeftRecClmn+j].setTo(inColor);
      }
    }
  }

  return validInputFound;
}

bool ColorImageClass::getChkPpmInsrt(int &upLeftRecRow, int &upLeftRecClmn, ColorClass &inColor, string fileNamePpmInsrt)
{
  int rowSizeInsrt, colSizeInsrt, mxValColorInsrt;
  string ppmMagicNum;

  ifstream inFile;
  bool validInputFound = true;

  inFile.open(fileNamePpmInsrt.c_str());

  if (inFile.fail())
  {
    cout << "Unable to open input file!" << endl;
  }

  inFile >> ppmMagicNum;
  if (ppmMagicNum != PPM_MAGIC_STRING)
  {
    cout << "The entered PPM file is not valid!" << endl;
    validInputFound = false;
  }
  if (inFile.eof())
  {
    cout << "EOF before reading PPM magic number" << endl;
    validInputFound = false;
  }
  else if (inFile.fail())
  {
    inFile.clear();
    inFile.ignore(200, '\n');
    validInputFound = false;
  }

  inFile >> colSizeInsrt;
  if (inFile.eof())
  {
    cout << "EOF before reading row-size" << endl;
    validInputFound = false;
  }
  else if (inFile.fail())
  {
    inFile.clear();
    inFile.ignore(200, '\n');
    validInputFound = false;
  }

  inFile >> rowSizeInsrt;
  if (inFile.eof())
  {
    cout << "EOF before reading column-Size" << endl;
    validInputFound = false;
  }
  else if (inFile.fail())
  {
    inFile.clear();
    inFile.ignore(200, '\n');
    validInputFound = false;
  }

  inFile >> mxValColorInsrt;
  if (inFile.eof())
  {
    cout << "EOF before reading Max color value" << endl;
    validInputFound = false;
  }
  else if (inFile.fail())
  {
    inFile.clear();
    inFile.ignore(200, '\n');
    validInputFound = false;
  }

  arrInsrt = new ColorClass*[rowSizeInsrt];

  for (int i = 0; i < rowSizeInsrt; i++)
  {
    arrInsrt[i] = new ColorClass[colSizeInsrt];
  }

  for (int i = 0; i < rowSizeInsrt; i++)
  {
    for (int j = 0; j < colSizeInsrt; j++)
    {
      arrInsrt[i][j].readFrmFile(inFile);
      if (!(arrInsrt[i][j].compareColor(inColor)))
      {
        arr[upLeftRecRow+i][upLeftRecClmn+j].setTo(arrInsrt[i][j]);
      }
    }
  }

  inFile.close();

  return validInputFound;
}

//A public fuction to print all pixels in the image  
void ColorImageClass::printImage(ofstream &outFile)
{
  for (int i = 0; i < rowSize; i++)  
  {
    for (int j = 0; j < colSize; j++)  
    {
      arr[i][j].printComponentValues(outFile);
    }
    outFile << endl;
  }
}

//A public fuction to write magic number, row, colmn, max 
//color, and all pixels into a file and make a PPM image file
void ColorImageClass::writeOutPpmFile(int &mxValColor, string fileNamePpm)
{
  ofstream outFile;

  outFile.open(fileNamePpm.c_str());

  if (outFile.fail())
  {
    cout << "Unable to open output file" << endl;
  }

  outFile << PPM_MAGIC_STRING << endl;
  outFile << colSize << " " << rowSize << endl;
  outFile << mxValColor << endl;

  printImage(outFile);

  outFile.close();
}

void ColorImageClass::deleteDynamicArry()
{
  for (int i = 0; i < rowSize; i++)
  {
    delete [] arr[i];
  }

  delete [] arr;
}
