#ifndef _COLORIMAGECLASS_H_
#define _COLORIMAGECLASS_H_
#include <iostream>
#include <fstream>

#include "RowColumnClass.h"
#include "ColorClass.h"

//Introducing ColorImageClass
class ColorImageClass{
private: 
  int rowSize, colSize, mxValColor;
  ColorClass **arr;
  ColorClass **arrInsrt;

public:
  ColorImageClass();

  void initializeTo(ColorClass &inColor);

  bool addImageTo(ColorImageClass &rhsImg);

  bool addImages(int numImgsToAdd,
                 ColorImageClass imagesToAdd []);

  bool setColorAtLocation(RowColumnClass &inRowCol,
                          ColorClass &inColor);

  bool getColorAtLocation(RowColumnClass &inRowCol,
                          ColorClass &outColor);

  bool getChkPpmFile(int &mxValColor, string fileNamePpm);

  bool getChkTxtFile(int &upLeftRecRow, int &upLeftRecClmn, ColorClass &inColor, string fileNameContPtrn);

  bool getChkPpmInsrt(int &upLeftRecRow, int &upLeftRecClmn, ColorClass &inColor, string fileNamePpmInsrt);

  void printImage(ofstream &outFile);

  void writeOutPpmFile(int &mxValColor, string fileNamePpm);

  void deleteDynamicArry();
};

#endif
